# topic-docx-packager: manba .docx dan mavzular ro'yxatini chiqaradi.
# Ishlatish:
#   powershell -ExecutionPolicy Bypass -File read_source.ps1 -Path "D:\...\manba.docx"
#   powershell -ExecutionPolicy Bypass -File read_source.ps1 -Path "D:\...\manba-papka"
# Fayl Word'da ochiq bo'lsa ham o'qiladi (FileShare.ReadWrite). Papka berilsa, undagi barcha .docx o'qiladi.
param(
    [Parameter(Mandatory = $true)][string]$Path
)

Add-Type -AssemblyName System.IO.Compression

function Get-DocxParagraphs {
    param([string]$File)
    $fs = [System.IO.File]::Open($File, 'Open', 'Read', 'ReadWrite')
    try {
        $zip = New-Object System.IO.Compression.ZipArchive($fs, [System.IO.Compression.ZipArchiveMode]::Read)
        $entry = $zip.GetEntry('word/document.xml')
        if ($null -eq $entry) { throw "word/document.xml topilmadi: $File" }
        $sr = New-Object System.IO.StreamReader($entry.Open(), [System.Text.Encoding]::UTF8)
        $xml = $sr.ReadToEnd()
        $sr.Close()
        $zip.Dispose()
    }
    finally {
        $fs.Close()
    }
    $lines = @()
    # Tartib bo'yicha barcha paragraflar (jadvallar ichidagilar ham)
    foreach ($m in [regex]::Matches($xml, '(?s)<w:p[ >].*?</w:p>')) {
        $v = $m.Value -replace '<w:tab/>', "`t"
        $parts = [regex]::Matches($v, '(?s)<w:t(?: [^>]*)?>(.*?)</w:t>') | ForEach-Object { $_.Groups[1].Value }
        $t = [System.Net.WebUtility]::HtmlDecode(($parts -join ''))
        if ($t.Trim() -ne '') { $lines += $t.Trim() }
    }
    return , $lines
}

if (-not (Test-Path -LiteralPath $Path)) {
    Write-Error "Yo'l topilmadi: $Path"
    exit 1
}

$item = Get-Item -LiteralPath $Path
if ($item.PSIsContainer) {
    $files = Get-ChildItem -LiteralPath $Path -Filter '*.docx' | Where-Object { $_.Name -notlike '~$*' } | Sort-Object Name
} else {
    $files = @($item)
}

foreach ($f in $files) {
    Write-Output ("== " + $f.FullName)
    $paras = Get-DocxParagraphs -File $f.FullName
    $i = 0
    foreach ($p in $paras) {
        $i++
        Write-Output ("[{0}] {1}" -f $i, $p)
    }
    Write-Output ("-- paragraflar: " + $paras.Count)
    Write-Output ""
}

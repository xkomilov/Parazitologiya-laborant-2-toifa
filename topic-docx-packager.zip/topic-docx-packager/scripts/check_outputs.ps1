# topic-docx-packager: natija papkasidagi NNN.docx fayllarini tekshiradi (builder'dan mustaqil).
# Ishlatish:
#   powershell -ExecutionPolicy Bypass -File check_outputs.ps1 -Dir "D:\...\Мавзу" [-Min 800] [-Expected 25]
# Tekshiruvlar: nom (NNN.docx), sarlavha, "Foydalanilgan adabiyotlar" bo'limi, asosiy matn so'zlari,
# [n] havolalar va adabiyot raqamlari mosligi, apostroflar (faqat oddiy ' bo'lishi kerak).
param(
    [Parameter(Mandatory = $true)][string]$Dir,
    [int]$Min = 800,
    [int]$Expected = 0
)

Add-Type -AssemblyName System.IO.Compression

function Get-DocxParagraphs {
    param([string]$File)
    $fs = [System.IO.File]::Open($File, 'Open', 'Read', 'ReadWrite')
    try {
        $zip = New-Object System.IO.Compression.ZipArchive($fs, [System.IO.Compression.ZipArchiveMode]::Read)
        $entry = $zip.GetEntry('word/document.xml')
        if ($null -eq $entry) { throw "word/document.xml yo'q" }
        $sr = New-Object System.IO.StreamReader($entry.Open(), [System.Text.Encoding]::UTF8)
        $xml = $sr.ReadToEnd()
        $sr.Close()
        $zip.Dispose()
    }
    finally {
        $fs.Close()
    }
    $lines = @()
    foreach ($m in [regex]::Matches($xml, '(?s)<w:p[ >].*?</w:p>')) {
        $v = $m.Value -replace '<w:tab/>', "`t"
        $parts = [regex]::Matches($v, '(?s)<w:t(?: [^>]*)?>(.*?)</w:t>') | ForEach-Object { $_.Groups[1].Value }
        $t = [System.Net.WebUtility]::HtmlDecode(($parts -join ''))
        if ($t.Trim() -ne '') { $lines += $t.Trim() }
    }
    return , $lines
}

function Count-Words {
    param([string[]]$Lines)
    $n = 0
    foreach ($l in $Lines) {
        $n += @($l -split '\s+' | Where-Object { $_ -ne '' }).Count
    }
    return $n
}

if (-not (Test-Path -LiteralPath $Dir)) { Write-Error "Papka topilmadi: $Dir"; exit 1 }

$files = Get-ChildItem -LiteralPath $Dir -Filter '*.docx' | Where-Object { $_.Name -notlike '~$*' } | Sort-Object Name
$rows = @()
$problems = 0
$apostropheRx = '[\u2019\u2018\u02BB\u02BC\u00B4`]'

foreach ($f in $files) {
    $notes = @()
    if ($f.Name -notmatch '^\d{3}\.docx$') { $notes += "nom NNN.docx emas" }
    $paras = @()
    try {
        $paras = Get-DocxParagraphs -File $f.FullName
    }
    catch {
        $notes += "o'qilmadi: $($_.Exception.Message)"
    }

    $words = 0
    $refCount = 0
    $citeText = ''
    if ($paras.Count -gt 0) {
        $refIdx = -1
        for ($i = 1; $i -lt $paras.Count; $i++) {
            if ($paras[$i].StartsWith('Foydalanilgan adabiyotlar')) { $refIdx = $i; break }
        }
        if ($refIdx -lt 0) {
            $notes += "'Foydalanilgan adabiyotlar' bo'limi yo'q"
            $bodyLines = @()
            if ($paras.Count -gt 1) { $bodyLines = $paras[1..($paras.Count - 1)] }
            $refLines = @()
        }
        else {
            $bodyLines = @()
            if ($refIdx -gt 1) { $bodyLines = $paras[1..($refIdx - 1)] }
            $refLines = @()
            if ($refIdx + 1 -lt $paras.Count) { $refLines = $paras[($refIdx + 1)..($paras.Count - 1)] }
        }
        $words = Count-Words -Lines $bodyLines
        $refCount = @($refLines | Where-Object { $_ -match '^\[\d+\]' }).Count
        $citeText = $bodyLines -join ' '

        if ($words -lt $Min) { $notes += "so'z $words < $Min" }
        if ($refCount -eq 0) { $notes += "adabiyot yozuvlari yo'q" }
        if ($citeText -match $apostropheRx) { $notes += "noto'g'ri apostrof (faqat ' bo'lsin)" }

        $cited = @{}
        foreach ($m in [regex]::Matches($citeText, '\[(\d+)\]')) { $cited[[int]$m.Groups[1].Value] = $true }
        foreach ($c in $cited.Keys) {
            if ($c -lt 1 -or $c -gt $refCount) { $notes += "[$c] adabiyotda yo'q" }
        }
        $unused = @()
        for ($k = 1; $k -le $refCount; $k++) { if (-not $cited.ContainsKey($k)) { $unused += $k } }
        if ($unused.Count -gt 0) { $notes += "ishlatilmagan manba: " + ($unused -join ', ') }
    }

    $status = 'OK'
    $hard = @($notes | Where-Object { $_ -notlike 'ishlatilmagan*' })
    if ($hard.Count -gt 0) { $status = 'XATO'; $problems++ }
    elseif ($notes.Count -gt 0) { $status = 'OGOH' }

    $rows += [pscustomobject]@{
        Fayl     = $f.Name
        Sarlavha = if ($paras.Count -gt 0) { $paras[0].Substring(0, [Math]::Min(40, $paras[0].Length)) } else { '' }
        Sozlar   = $words
        Manba    = $refCount
        Holat    = $status
        Izoh     = ($notes -join '; ')
    }
}

$rows | Format-Table -AutoSize -Wrap | Out-String -Width 400 | Write-Output
Write-Output ("Jami fayl: {0}" -f $files.Count)
if ($Expected -gt 0) {
    if ($files.Count -eq $Expected) { Write-Output ("Kutilgan {0} ta fayl: mos" -f $Expected) }
    else { Write-Output ("DIQQAT: kutilgan {0}, mavjud {1}" -f $Expected, $files.Count); $problems++ }
}
if ($rows.Count -gt 0) {
    $short = @($rows | Where-Object { $_.Sozlar -lt $Min })
    if ($short.Count -gt 0) { Write-Output ("Minimumdan kam: " + (($short | ForEach-Object { $_.Fayl }) -join ', ')) }
}
if ($problems -gt 0) { Write-Output ("Xatolar bor: {0}" -f $problems); exit 1 }
Write-Output "Barcha tekshiruvlar o'tdi (XATO yo'q)."
exit 0

---
name: topic-docx-packager
description: Mavzular ro'yxatini saqlagan manba .docx dan har bir mavzu uchun alohida, ilmiy, kamida 800 so'zli, manbali (adabiyotlar bilan) 001.docx...NNN.docx paket tayyorlash. Istalgan soha uchun universal. "paketli mavzular", "röyxat bo'yicha mavzular", "mavzu paketi", "har bir mavzuga alohida docx", "001.docx" so'rovlarida ishlatiladi.
---

# Mavzu paketi → alohida .docx (universal)

Manbadagi mavzular ro'yxatidan har bir mavzu uchun alohida, ilmiy va manbali `.docx` fayl yoziladi (`001.docx`, `002.docx` ...). Matn o'zbek tilida, lotin yozuvida. Asos: `D:\PROMPT\Röyxat böyiça paketli mavzular tayyorlaş.docx`.

Skill fayllari: `C:\Users\xkomilov\.claude\skills\topic-docx-packager\`
- `scripts\read_source.ps1` — manba .docx dan mavzular ro'yxatini o'qiydi
- `scripts\build_docx.js` — JSON spec → NNN.docx (hajm va manba tekshiruvi bilan)
- `scripts\check_outputs.ps1` — natija papkasini mustaqil tekshiradi
- `references\sources-policy.md` — manba ustuvorligi va tekshirish qoidalari (majburiy o'qing)
- `references\changelog.md` — seans o'zgartirishlari jurnali

## 0. Seans boshida (majburiy — avval so'raladi)

Ishni boshlashdan oldin foydalanuvchidan bitta xabarda so'rang:

1. **Manba** — mavzular ro'yxati saqlangan `.docx` fayl yoki papka yo'li (majburiy).
2. **Natija papkasi** — tayyor `NNN.docx` fayllar yoziladigan papka (majburiy).
3. **Soha / rol** — masalan "epidemiolog, virusolog, immunolog, parazitolog". Berilmasa, manba faylning boshidagi rol tavsifidan olinadi.
4. **Qo'shimcha ma'lumot papkasi** (ixtiyoriy) — kutubxona materiallari (masalan `D:\KUTUBXONA`). Berilmasa faqat internet manbalari ishlatiladi.

Javoblarni `<manba-papkasi>\_build\session.json` ga yozing (`{"source":..., "output":..., "role":..., "library":...}`). Foydalanuvchi berilgan yo'llarni o'zgartirmasdan ishlating; bo'sh joy yoki kirill harflar bo'lsa, yo'lni qo'shtirnoq ichida yuboring.

## 1. Manbani o'qish va rejani ko'rsatish

```
powershell -ExecutionPolicy Bypass -File "D:\TEST\.claude\skills\topic-docx-packager\scripts\read_source.ps1" -Path "<manba>"
```

- Mavzular sonini va rejani ko'rsating: raqam, nomi (qanday yozilgan bo'lsa, shunday).
- Raqamlar uzluksizmi, takrorlar bormi — tekshiring. Shubhali bo'lsa, davom etishdan oldin so'rang.
- Fayl nomi tartib raqami bo'yicha: `001.docx` ... `NNN.docx` (uch xonali).
- Manba Word'da ochiq bo'lsa ham o'qiladi.

## 2. Partiyalab ishlash

- Mavzularni **8–10 tadan** partiyalarga bo'ling.
- **Birinchi partiyani** tayyorlab, foydalanuvchiga ko'rsating: fayllar, har birining so'z soni, manbalar soni, tasdiqlanmagan faktlar. Shu yerda so'rang: so'z hisobi qoidasi (sarlavha va adabiyotlar hisobga kirmaydi) to'g'rimi.
- Foydalanuvchi tasdiqlagach, qolgan partiyalarni **mustaqil** oxirigacha bajaring. Har partiyadan keyin `check_outputs.ps1` bilan tekshiring.
- Bir partiyada fayllar yozilgandan keyin tekshiruv natijasini (fayllar soni va formati) qisqa qayd eting.

## 3. Har bir mavzu uchun matn talablari (qat'iy)

- **Til va apostrof**: o'zbekcha, lotin yozuvi. Apostrof faqat oddiy `'` (masalan `o'q`, `g'oya`, `ma'lumot`). Builder boshqa apostroflarni (`’ ʻ ʼ`) avtomatik almashtiradi.
- **Hajm**: asosiy matn kamida **800 so'z**. Sarlavha va "Foydalanilgan adabiyotlar" bo'limi hajmga kirmaydi (taxmin — birinchi partiyada tasdiqlatiladi). Bo'lim sarlavhalari hajmga kiradi. Maksimal chegara yo'q.
- **Sarlavha**: mavzu nomi manbada qanday yozilgan bo'lsa, shunday, raqami bilan (masalan `12.[mavzu nomi]`).
- **Tuzilma**: qisqa **Kirish** → mavzuga mos asosiy bo'limlar (masalan: ta'rif, etiologiya/biologiya, epidemiologiya, klinika, laboratoriya tashxisi, me'yorlar va ko'rsatkichlar, profilaktika, davolash — mavzuga mosini tanlang) → **Xulosa** → **Foydalanilgan adabiyotlar**.
- **Sanaladigan qismlar**: ro'yxatlar spec'da `{"ul": [...]}` yoki `{"ol": [...]}` ko'rinishida yoziladi. Matnga qo'lda `•` yoki `1.` yozmang.
- **Havolalar**: har bir muhim fakt, raqam va me'yor yonida `[n]`. Iqtibos qisqa va tirnoq ichida, manba raqami bilan.
- **Adabiyotlar**: muallif, nom, nashr/tashkilot, yil, DOI/URL (faqat tekshirilgan bo'lsa). Tasdiqlanmagan manba `[tasdiqlanmagan]` deb belgilanadi.
- **Takroriy va o'xshash savollar** (foydalanuvchi qarori, 2026-11-09): har bir savol uchun alohida `.docx` yoziladi (takrorlar birlashtirilmaydi). Bir xil savol (faqat imlo farqi bo'lsa ham) bo'lsa, javob matni ham bir xil yoziladi. O'xshash, lekin boshqa savol bo'lsa, javob savol konteksti (qaysi gijja/bezgak/usul, qaysi jihat so'ralgan)dan kelib chiqib yoziladi. Barcha matnlar qo'lda yoziladi: generator skript yoki kalit-fayl orqali takrorlash ishlatilmaydi.
- **Manba tekshiruvi**: `references\sources-policy.md` qoidalari. Avval kutubxona papkasi (agar berilgan bo'lsa), keyin rasmiy manbalar, keyin xalqaro manbalar. DOI va JSST raqamlari WebSearch/WebFetch orqali tekshiriladi. O'zbekistonga xos raqamlarni tasdiqlay olmasangiz, taxmin qilmang.

## 4. Spec yozish va fayl qurish

Har bir mavzu uchun `<manba-papkasi>\_build\specs\NNN.json` yozing:

```json
{
  "number": 1,
  "title": "1-mavzu. Mavzu nomi",
  "sections": [
    { "heading": "Kirish", "content": [
        "Paragraf matni, fakt [1].",
        { "ul": ["sanalmagan band", "yana band"] },
        { "ol": ["birinchi qadam", "ikkinchi qadam"] }
    ]},
    { "heading": "Xulosa", "content": ["Xulosa matni [2]."] }
  ],
  "references": [
    "Muallif. Kitob nomi. Nashriyot, 2020.",
    "JSST. Qo'llanma nomi. Jeneva, 2021. DOI: ... [tasdiqlanmagan]"
  ]
}
```

Qurish (bir marta `docx` paketini o'rnating; loyihaga qo'shilmaydi):

```bash
npm install --prefix "%TEMP%\topic-docx-deps" docx
```

```bash
node "D:\TEST\.claude\skills\topic-docx-packager\scripts\build_docx.js" --dir "<manba-papkasi>\_build\specs" "<natija-papkasi>"
```

- Minimumdan kam mavzu yozilmaydi (`QISQA` xabari). Uni spec'da to'ldirib, qayta qurish kerak.
- `--min` bilan minimumni o'zgartirish mumkin (faqat foydalanuvchi so'ragan holda).
- Ogohlantirishlar (`[n] adabiyotlarda yo'q`, `ishlatilmagan manba`) — tuzating.
- Fayl Word'da ochiq bo'lsa `YOZILMADI` chiqadi: yopib qayta ishga tushiring.

## 5. Tekshirish

```
powershell -ExecutionPolicy Bypass -File "D:\TEST\.claude\skills\topic-docx-packager\scripts\check_outputs.ps1" -Dir "<natija-papkasi>" -Min 800 -Expected <mavzular soni>
```

Holat ustuni: `OK`, `OGOH` (ogohlantirish), `XATO` (tuzatish shart). Oxirgi qator "XATO yo'q" bo'lishi kerak. Natija `XATO` bo'lsa, faqat o'sha faylni tuzating va qayta qurib tekshiring.

## 6. Seans o'zgartirishlari

Foydalanuvchi sessiya davomida kiritgan **har bir** o'zgartirishni (matn, tartib, manba, format, papka, hajm qoidasi) darhol `references\changelog.md` ga sana va qisqa tavsif bilan yozing. Agar o'zgartirish skill qoidasiga ta'sir qilsa, SKILL.md ni ham yangilang. O'zgartirishlarni xotirada saqlashga tayanmang.

## 7. Yakuniy hisobot (o'zbekcha)

1. Yaratilgan fayllar soni va ro'yxati; manbadagi mavzular soni bilan solishtirish.
2. So'z soni: eng kichik va eng katta; minimumdan kam fayl yo'q.
3. **Tasdiqlanmagan faktlar** ro'yxati: fayl, bo'lim, fakt.
4. **Farq qiladigan joylar**: rasmiy manbalar bir-biridan qayerda farq qiladi (raqam, muddat, me'yor).
5. Ochiq qolgan joylar va qo'lda tekshirish kerak bo'lganlar.
6. Seans o'zgartirishlari (`changelog.md` ga havola).

Hisobotda ko'rsatilgan har bir raqam tekshiruv natijasiga asoslangan bo'lsin. Tekshirilmagan narsani tekshirilgan deb yozmang.

## Eslatmalar

- `check_outputs.ps1` builder'dan mustaqil tekshiradi; ikkalasini ham ishga tushiring.
- Mavzular soni katta bo'lsa (50+), partiya boshiga qisqa holat yozing: "N/M tayyor, qolgani: ...".
- Builder ma'lumotlarni ko'rsatilgan `number` bo'yicha nomlaydi; bir xil raqamli ikki spec bo'lsa, oxirgisi ustiga yoziladi — shuni tekshiring.

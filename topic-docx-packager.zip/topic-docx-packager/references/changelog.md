# O'zgarishlar jurnali (topic-docx-packager)

Qoida: sessiya davomida foydalanuvchi kiritgan har bir o'zgartirish (matn, tartib, manba, format, papka, hajm qoidasi va h.k.) shu yerga sana bilan yoziladi. Skill qoidasiga ta'sir qilsa, SKILL.md ham yangilanadi.

## 2026-11-08 — Skill yaratildi

- Asos: foydalanuvchi prompt fayli `D:\PROMPT\Röyxat böyiça paketli mavzular tayyorlaş.docx` (Epidemiolog/virusolog/immunolog/parazitolog uchun mavzu paketlari).
- Universal qilindi: manba, natija papkasi, soha/rol va qo'shimcha kutubxona papkasi seans boshida so'raladi.
- Hajm qoidasi: sarlavha va "Foydalanilgan adabiyotlar" hajmga kirmaydi; bo'lim sarlavhalari kiradi. Bu prompt tomonidan "tasdiqlash kerak bo'lgan taxmin" deb belgilangan — birinchi partiyada foydalanuvchi tasdiqlashi kerak.
- Partiya ish tartibi: 8–10 mavzu/partiya; birinchi partiya tasdiqlangach qolgani mustaqil bajariladi.

## Ochiq savollar (tasdiqlanishi kerak)

- So'z hisobi qoidasi (yuqoridagi taxmin).
- Kutubxona papkasi (`D:\KUTUBXONA`) — faqat shu prompt uchun berilgan; universal skillda seans boshida so'raladi.

## 2026-11-08 — Seans: 1-partiya (001–010) tayyorlandi

- Manba: `D:\TEST\Эпидемиология\Эпидемиология шифокор ёрдамчиси\2-тоифа\Epidemiolog vrach yordamchilari uchun 2-тоифа.docx` (153 qator; 1–2 qatorlar sarlavha, shuning uchun 151 mavzu deb olindi — tasdiqlash kerak).
- Natija: `D:\TEST\Эпидемиология\Эпидемиология шифокор ёрдамчиси\2-тоифа\Мавзу`.
- Soha: epidemiolog vrach yordamchisi (prompt matnidan).
- Kutubxona: `D:\KUTUBXONA` (975 fayl) — 001–010 uchun o'qilgan manbalar: Umirov 2012 (1-bob, adabiyotlar), Mirtazaev 2016 (8-bob, yuqish mexanizmi), KPI hujjati (ҳудудий бўлим), Zornikov 2016, «ЭМЛАШ КАЛЕНДАРИ».
- Kutubxona + veb manbalar: Plotkin 2010 (DOI 10.1128/CVI.00131-10) va WHO «Immunization in Practice» 2015 (ISBN 978-92-4-154909-7) veb orqali tekshirildi.
- Ma'lum kamchilik: ko'p umumiy faktlar [1]/[2] manbalariga bog'langan, lekin matnning har bir jumlasi sahifa bo'yicha tekshirilmagan.

## 2026-11-08 — Seans o'zgarishi: sarlavha formati

- Foydalanuvchi so'rovi: sarlavha "1-mavzu. ..." emas, "1. [Mavzu nomi]" ko'rinishida bo'lsin.
- Amal: barcha spec sarlavhalari shu formatga o'tkazildi (`N. Mavzu nomi`). Builder o'zgarmadi, sarlavha spec'dan olinadi.
- Qoida: keyingi yangi spec'larda sarlavha `"N. Mavzu nomi"` ko'rinishida yoziladi.
- Holat: mavzular soni 151 (tasdiqlangan). 1–20 tayyor; 21–30 hali minimumga yetmagan; 31–151 boshlanmagan.

## 2026-11-08 — Yakuniy holat: 151 ta mavzu

- Natija papkasi: `D:\TEST\Эпидемиология\Эпидемиология шифокор ёрдамчиси\2-тоифа\Мавзу` — 151 ta fayl (001.docx … 151.docx).
- Spec manbasi: `...\2-тоифа\_build\specs\` (151 ta JSON). Builder: `--min 800`, barcha fayllar OK. Mustaqil tekshiruv (check_outputs.ps1): XATO yo'q.
- Sarlavhalar: `N. Mavzu nomi` formati (nol bilan boshlanmaydi; 041, 081, 101 kabi nomlar normalizatsiya qilindi).
- Parallel agentlar 13 ta guruh bo'yicha yozdi (G01–G13). Har bir guruh o'z tekshiruvini bajardi.
- Ochiq masalalar (fayllar bo'yicha [tasdiqlanmagan] belgilari bor):
  - 057 (botulizm), 139 (oqsim atamasi), 148–149 (qoqshol klinikasi), 135–136, 138: manbada ma'lumot yetarli emas.
  - Sterilizatsiya/dezinfeksiya raqamlari (111, 114, 115, 118 va 1655/1656 PDF) OCR matnidan; asl nusxa bilan tekshirish kerak.
  - Manbalar o'rtasidagi ziddiyatlar: 134 (KQT endemikligi), 127 (Qrim isitmasi), 108 (faol xlor 66%/35%), 109–110 (spirt 95%/97%), 096 (kamera rejimi).
  - Mirtazaev darsligi bob darajasida havola qilingan; sahifalar tekshirilmagan.
- Qolgan holat: yo'q. Barcha 151 mavzu tayyor.

## 2026-11-09 — Yangi seans: Parazitologiya manbasi (121 savol)

- Manba: `D:\TEST\Паразитолог лаборант\Шифокор\Паразитолог-лаборант шифокор  олий тоифа врач\Parazitar kasalliklar laboratoriya diagnostikasi mutaxassisligi oliy-toifa.docx`. Natija: `...\Мавзу`. Kutubxona: `D:\KUTUBXONA` (791 PDF).
- Rol o'zgartirildi: avval "epidemiolog" deb yozilgan edi, foydalanuvchi so'rovi bilan "Parazitologiya bo'yicha oliy toifali shifokor" qilindi.
- Sarlavha qoidasi: mavzu sarlavhasi — manbadagi savol matni, raqam 1–121, format `N. <savol>`. Ba'zi savollarda imlo tuzatildi (003, 004, 005, 010 sarlavhalari).
- Takrorlar joyida qoldirildi (23 ta aniq takror). Bir xil mavzuga bir xil asosiy javob; javob aniq mavzu doirasida yoziladi.
- Partiya 1 (001–010) yozildi, 800 so'z minimumi bilan OK. So'z hisobi qoidasi (sarlavha va adabiyot hisobga kirmaydi) hali tasdiqlanmagan.
- Muammo: D:\KUTUBXONA dagi kirill PDF'larning matn qatlami buzuq (pdftotext harflarni yo'qotadi); poppler (pdftoppm) yo'q, shuning uchun sahifalarni ko'rib o'qib bo'lmadi. Ochiq o'qilganlar: Vikipediya «Bezgak» (lotin), «Безгакни даволаш протоколи» (qisman). Partiya 1 faktlari asosan umumiy parazitologik bilimga va CDC/JSST qidiruv natijalariga tayanadi, shu sabab ko'p manbalar [tasdiqlanmagan] deb belgilangan.
- Hal qilinmagan: kirill PDF'larni o'qish uchun poppler o'rnatish yoki OCR. Foydalanuvchi qaror beradi.

## 2026-11-09 — Tasdiqlangan: 1-partiya; 11–121 uchun qoidalar

- Foydalanuvchi tasdiqladi: 001–010 va so'z hisobi (sarlavha va adabiyot hisobga kirmaydi, minimum 800).
- Takrorlar: 121 ta fayl, takrorlar joyida. Bir xil mavzuga bir xil javob: matn kalitlar bo'yicha (`_build\keys\<KEY>.json`) yoziladi, `_build\gen.js` raqam va savol sarlavhasini qo'yib 11–121 specs yaratadi.
- Mavzu kalitlari: masalan ENT_tape (n=11,12), L_joy (4,13,107), M_yuqish (9,30,50,80,85,101,112), M_chivin (38,61,90) va boshqalar. Ba'zi o'xshash savollar (masalan "Bezgak nimaning chaqishidan..." va "Bezgak qanday yuqadi") bitta mavzu deb qabul qilindi.
- Holat: 22 ta fayl 800+ so'z bilan yozildi (001–010, 013, 023, 030, 050, 080, 085, 087, 099, 101, 107, 112, 116). Qolgan ~99 ta spec hali 800 so'zga yetmagan (ko'pi 170–600 so'z). Kengaytirish davom etmoqda.
- Muammo: kirill kutubxona PDF'lari o'qilmaydi (poppler yo'q). Matnlar umumiy bilim va CDC/JSST qidiruv natijalariga tayanadi; ko'p manbalar [tasdiqlanmagan].
- Eslatma: mavzu 1-121 uchun savol sarlavhalarida ba'zi imlo tuzatildi.

## 2026-11-09 — 121 ta fayl tayyor (ichki kalitlar orqali)

- Foydalanuvchi qarori: kirill kutubxona PDF'lar o'qilmaydi, shu sabab xalqaro manbalar veb-qidiruv orqali qidirildi (WHO, CDC DPDx/Yellow Book, PAHO, PMC). Qo'shimcha OCR qilinmadi.
- Usul: takrorlar bitta mavzu kalitiga (`_build\keys\<KEY>.json`) bog'landi, `_build\gen.js` 11–121 specs ni yaratadi; 1–10 alohida yozilgan.
- Natija: `Мавзу` papkasida 121 ta NNN.docx, har biri 800+ so'z (`check_outputs.ps1 -Min 800 -Expected 121`: XATO yo'q).
- Ma'lum kamchiliklar: matnlar umumiy parazitologik bilimga asoslangan, ko'pi manba ko'rsatilgan lekin to'liq o'qilmagan; ayrim faktlar [tasdiqlanmagan]; ko'p bo'limlar bir-biriga o'xshash (takror tuzilma); dozalar va aniq muddatlar milliy protokol tasdig'isiz berilmagan. Ekspert tekshiruvi kerak.

## 2026-11-09 — Yangi seans: 1-toifa manbasi (118 savol), qayta yozish

- Manba: `D:\TEST\Паразитолог лаборант\Шифокор\Паразитолог-лаборант шифокор  1-тоифа врач\Parazitar kasalliklar laboratoriya diagnostikasi mutaxassisligi 1-toifa.docx` (121 qator: 3 ta sarlavha + 118 savol). Natija: `...\1-тоифа врач\Мавзу`. Rol: Parazitologiya bo'yicha oliy toifali shifokor.
- Raqamlash: fayl NNN = manba savoli (qator NNN+3). Sarlavha: `N. <savol matni>`.
- Eski holat: `Мавзу` papkasidagi 118 ta fayl tekshiruvdan o'tmadi (adabiyot bo'limi yo'q, 60+ tasi 800 so'zdan kam, apostroflar noto'g'ri). Foydalanuvchi papkani tozaladi; eski fayllar qayta yozildi.
- Qaror (foydalanuvchi, 2026-11-09): 118 ta alohida fayl. Bir xil savol — bir xil javob; o'xshash savol — kontekstdan kelib chiqib javob. Hammasi qo'lda yoziladi: `_build\keys` va `gen.js` usuli bu seansda ishlatilmaydi. Qoida SKILL.md 3-bandiga kiritildi.
- Takroriy/o'xshash savollar (manba qatori -> fayl): [17], [43], [79] ho'kiz tasmasi oxirgi xo'jayini -> 014, 040, 076; [60]/[61] askaridoz klinikasi -> 057, 058; [101], [104], [112], [115] lambliya sistalari materiali -> 098, 101, 109, 112; [66]/[113] qilbosh oxirgi xo'jayini -> 063, 110; [9]/[33] chivin nazorati -> 006, 030; [59]/[90] appenditsitga o'xshash gelmintoz -> 056, 087; [89]/[93] tez-tez uchraydigan dastlabki belgilar -> 086, 090; [84] -> 081.
- Muhit cheklovi: `D:\KUTUBXONA` dagi kirill PDF'larni o'qib bo'lmadi (`pdftoppm` yo'q, Python yo'q, Read PDF render qila olmadi). 121-buyruq ilovalari faqat fayl nomi bo'yicha havola qilinadi; matn faktlari [tasdiqlanmagan].
- Tekshirilgan manbalar (veb, 2026-11-09): WHO malaria guidelines (yangilanish 13.08.2025); Garcia 6th ed. (ASM Press, 2016); WHO TRS 949 (2010); WHO STH guideline (2017); Manson 23rd ed. (Elsevier, 2014); CDC DPDx.
- Holat (2026-11-09, seans oxiri): `_build\specs` da 001–028 spec yozildi. 001–023 builder bo'yicha OK (800+ so'z). 024–028 ham OK (800+). 029 va 031 hali 800 dan kam (500–540 so'z). 030, 032–118 hali yozilmagan. Mavzu papkasida hozircha 28 ta fayl (001–028).
- Holat (davomi): 001–038 va nusxa savollar (030, 032, 040, 054, 077, 088, 091, 092, 096, 098, 101, 112) yozildi, builder bo'yicha OK. Qolgan savollar: 039, 041–053, 055–057, 058(=057), 059–073, 074(=053), 075, 076(=014), 078, 079(=072), 080(=048), 081–086, 087(=056), 089, 090(=086), 093–095, 097, 099, 100, 102–111 (110=063, 111=048), 113–118.
- Holat (yangilangan): 001–047 (copy: 030, 032, 040, 054, 077, 088, 091, 092, 096, 098, 101, 112) builder bo'yicha OK. Qolgan: 048–053, 055–057, 058(=057), 059–073, 074(=053), 075, 076(=014), 078, 079(=072), 080(=048), 081–086, 087(=056), 089, 090(=086), 093–095, 097, 099, 100, 102–109, 110(=063), 111(=048), 113–118.
- Holat (2026-11-09, so'nggi): 001–051 va nusxalar (030, 032, 040, 054, 076, 077, 080, 088, 091, 092, 096, 098, 101, 111, 112) builder bo'yicha OK. 052 spec yozilgan, lekin 515 so'z (kam). Qolgan: 053, 055–057, 058(=057), 059–073, 074(=053), 075, 078, 079(=072), 081–086, 087(=056), 089, 090(=086), 093–095, 097, 099, 100, 102–109, 110(=063), 113–118.
- Muhim: yangi fayl uchun ~25 so'zli paragraflar kam so'z beradi; har bir fayl uchun 800 ga yetish odatda 10–15 ta qo'shimcha tahrir talab qiladi. Tezroq yo'l: minimumni ko'rib chiqish (foydalanuvchi qarori kerak).
- Ish usuli: asl savol yozilgandan keyin Edit bilan 1–3 bo'lim qo'shiladi, so'ng builder. Har bir fayl ~6–10 chaqiruv talab qiladi.
- Muhim saboq: qisqa paragraflar so'z hisobini kam ko'rsatadi; har bir faylga kamida 16–20 paragraf (har biri 40+ so'z) yozish kerak, aks holda builder "QISQA" beradi. Yozuv yo'nalishi: `build_docx.js` qayta ishga tushiriladi, keyin `check_outputs.ps1`.
- Takroriy savollar uchun nusxa: 030 = 006, 040 = 014, 058 = 057, 063 = 110, 054 = 023, 074 = 053, 076 = 014, 077 = 021, 087 = 056, 088 = 013, 090 = 086, 091 = 027, 092 = 008, 096 = 021, 098/101/109/112/020 — bir xil javob (sistalar materiali), 111 = 048, 114 ≈ 102 (qalin tomchi), 118 ≈ 020... (to'liq ro'yxat ishda tekshiriladi).

## 2026-11-09 — Yakuniy holat: 118 ta fayl, 800+ so'z

- Barcha 118 spec yozildi (`_build\specs\001.json`–`118.json`); nusxalar: 030, 032, 040, 054, 074, 076, 077, 079, 080, 087, 088, 090, 091, 092, 096, 098, 101, 110, 111, 112. `build_docx.js`: 118 OK, muammo 0. `check_outputs.ps1 -Min 800 -Expected 118`: XATO yo'q.
- Sarlavhalar manba savol matniga moslashtirildi (094, 095, 100, 102, 103, 105–109, 113–118); 117 dagi "qoydalanamiz" imlosi "foydalanamiz" qilib tuzatildi.
- Ochiq / tasdiqlanmagan: 114 (BM-SOM-№05), 118 (BM-SOM-№09) va 115 (metodik qo'llanma nomi) hujjatlarining matni o'qilmagan — umumiy xalqaro usul bayon qilingan, hujjatga havola [tasdiqlanmagan] deb belgilangan. 117 dagi 121-buyruq ilovasi ham o'qilmagan.
- 089 savolining ma'nosi noaniq ("o'z doirasini tark etmaydi"); P. falciparum javob qilib berildi, gipnozoit farqi [tasdiqlanmagan].
- Dozalar (mebendazol, albendazol, pirantel, primaxin, praziquantel) xalqaro manbalarga tayanadi; milliy protokol bilan tasdiqlanmagan — ishlatishdan oldin tekshiriladi.
- Saboq: spec'ni 800 ga yetkazish uchun odatda paragraflar sonini ~1.5–2 barobar oshirish kerak. Yangi spec'lar 12–16 bo'lim, har bir bo'lim 2 paragraf, har bir paragraf 40+ so'z qilib yozilsa, birinchi qurishda OK chiqadi.

## 2026-11-09/10 — Seans: 2-toifa esse paketi (120 savol)

- Manba: `D:\TEST\Паразитолог лаборант\Шифокор\Паразитолог-лаборант шифокор  2-тоифа врач\` savollar docx (120 savol) va foydalanuvchining og'zaki javoblar hujjati (`_build\doc_answers\NNN.txt`). Natija: `...\2-тоифа врач\Мавзу_esse`. Spec: `_build\specs_essay`. Rol: Parazitologiya bo'yicha oliy toifali shifokor.
- Foydalanuvchi uslub qoidalari (5 band): 1) bitta savol = bitta esse: sarlavha-savol, Kirish, 5–8+ nomlangan bo'lim, Xulosa, adabiyotlar; 2) havolalar faqat faktlarda, paragraf oxirida birlashtirilib; 3) raqamlangan adabiyotlar ro'yxati: manba nomi, URL, «Tekshiruv holati»; 4) kamida 800 so'z (builder hisobi); 5) istalgan manba mumkin, tekshirilmagani holati bilan belgilanadi.
- Qo'shimcha qaror: tekshirilmagan manbani tekshirilgan deb ko'rsatmaslik; asos — foydalanuvchi hujjati, tekshirilgan manbalar bilan birga; jumlalar takrorlanmaydi; bir xil savol → bir xil esse (nusxa), o'xshash savol → kontekstga mos.
- Nusxalar: 006=067, 008=076, 026=071, 031=065, 032=051, 035=069=073, 048=068, 060=077, 081=100, 087=116, 098=115, 103=111, 001=042, 083=090.
- Yordamchi skriptlar (`_build\tools`): prune_refs.js, add_section.js, copy_spec.js, check_cites.js (ul/ol ichini ham tekshiradi).
- Yakun (2026-11-10): 120 ta NNN.docx; `check_outputs.ps1 -Min 800 -Expected 120` — XATO yo'q; so'z soni 800–1080.
- 2026-11-10 (foydalanuvchi): `Мавзу_esse` sarlavhalari ikki xil raqamlangan edi («001.» va «5.»). Hammasi «1.»–«120.» ko'rinishiga keltirildi (raqam oldidagi nollar olib tashlandi); fayl nomlari NNN.docx bo'lib qoldi. Qoida: sarlavhada raqam nolsiz yoziladi.

## 2026-11-11 — Seans: Laborant (oliy toifa), 148 mavzu, esse uslubida qayta yozish

- Manba: `D:\TEST\Паразитолог лаборант\Лаборант-янги\олий тоифа лаборант-янги\Мавзу1` (148 ta mavzu docx; har biri 301–867 so'z, adabiyotlar bilan). Natija: `...\Мавзу`. Kutubxona: `D:\KUTUBXONA` (975 fayl). Rol: Parazitologiya bo'yicha oliy toifali shifokor. Ish papkasi: `...\олий тоифа лаборант-янги\_build` (specs, src_txt, session.json).
- Foydalanuvchi qarori: mavjud `Мавзу1` matnlari asos qilib olinadi, esse uslubida kengaytirib qayta yoziladi (faktlar va tekshirilgan havolalar saqlanadi); kamida 800 so'z.
- Foydalanuvchi qarori (SKILL.md 3-band o'zgardi): havolalar har bir fakt yonida emas, **abzats oxirida** beriladi, masalan `... [1, 3].`
- Sarlavha: `N. Mavzu nomi` (nolsiz, birinchi harf katta, qolgani kichik).
- Skriptlar: `build_docx.js` va `check_outputs.ps1` endi `[1, 2]` va `[1–3]` ko'rinishidagi birlashgan havolalarni taniydi (avval faqat `[1]` tanilar edi, shuning uchun soxta "ishlatilmagan manba" ogohlantirishi chiqardi).
- Foydalanuvchi so'rovi: muloqot o'zbek tilida; ruxsat so'ralganda buyruq maqsadi o'zbekcha yoziladi; ish avtomatik (to'xtovsiz) bajariladi.
- Holat (2026-11-11): 1-partiya (001–010) `Мавзу` ga yozildi; builder va `check_outputs.ps1 -Min 800 -Expected 10`: XATO yo'q (801–841 so'z, 6–15 manba). Faktlar `Мавзу1` matnlaridan olindi, yangi faktlar qo'shilmadi (qo'shilganlari umumiy parazitologik bilim, mavjud manbalarga bog'landi). Foydalanuvchi qarori: tayyor fayllar darhol `Мавзу` ga yoziladi. Saboq: esse uchun 9–11 bo'lim, har biri 2 paragraf (60–90 so'z) yozilsa birinchi qurishda 800+ chiqadi.
- 2026-11-11 (foydalanuvchi tasdig'i): so'z hisobiga sarlavha va adabiyotlar ro'yxati kirmaydi, minimum 800 so'z. Holat: 001–020 `Мавзу` ga yozildi, `check_outputs.ps1 -Min 800 -Expected 20` XATO yo'q (800–866 so'z).
- Texnik saboq: bir turda ko'p `str_replace` qilib, tur uzilsa, tahrirlar yo'qolishi mumkin. Har partiyada tahrirdan keyin shu turning o'zida qurish va natijani tekshirish kerak. `permissions.yaml` (IDE 1.x) foydalanuvchi tomonidan yaratildi: `node *` va `powershell -ExecutionPolicy Bypass -File *` so'rovsiz ishlaydi.
- Holat (2026-11-11): 001–040 `Мавзу` ga yozildi; `check_outputs.ps1 -Min 800 -Expected 40` XATO yo'q (800–868 so'z). Saboq: 10 bo'lim x 2 abzats yetmaydi (~700–750 so'z chiqadi); birinchi yozishdayoq 12–13 bo'lim, har abzats 70+ so'z yozish kerak.
- Holat (2026-11-11): 001–050 `Мавзу` ga yozildi; `check_outputs.ps1 -Min 800 -Expected 50` XATO yo'q (800–905 so'z). Qoldi: 051–148 (98 ta). Saboq: bir bo'lim 2 abzats ≈ 70 so'z; 800 so'zga yetish uchun kamida 14 bo'lim (yoki 3 abzatsli bo'limlar) kerak.
- Holat (2026-11-11): 001–060 `Мавзу` ga yozildi; `check_outputs.ps1 -Min 800 -Expected 60` XATO yo'q (800–905 so'z). Qoldi: 061–148 (88 ta). 051–060 faktlari `Мавзу1` matnlaridan olindi; 057–058 O'zbekiston ma'lumotlari Kovalenko 2011 (Parasites & Vectors) va Kovalenko 2011 (Med. Parazitol.) maqolalaridan.
- Holat (2026-11-11): 001–070 `Мавзу` ga yozildi; `check_outputs.ps1 -Min 800 -Expected 70` XATO yo'q (800–921 so'z). Qoldi: 071–148 (78 ta). 061–070 (leyshmanioz davolash va KQT) faktlari `Мавзу1` matnlaridan olindi; KQT mavzularida milliy hujjat va akaritsid ro'yxati tasdiqlanmagan deb belgilangan (064, 066, 069).
- Holat (2026-11-11): 001–110 `Мавзу` ga yozildi; `check_outputs.ps1 -Min 800 -Expected 100` XATO yo'q (100 gacha tekshirildi). Qoldi: 111–148. 071–110 faktlari `Мавзу1` matnlaridan olindi; qo'shilgan umumiy bo'limlar (laboratoriya xodimi roli, differensial tashxis va h.k.) manba bilan jumlama-jum solishtirilmagan. Tasdiqlanmagan-ma'lumot bo'limlari: 092, 093, 094 (Rossiya uslubiy ko'rsatmalari O'zbekistonga mosligi), 101 (veterinariya me'yorlari va muzlatish rejimi).
- Holat (2026-11-11): 001–148 `Мавзу` ga yozildi; `check_outputs.ps1 -Min 800 -Expected 148` XATO yo'q (800–1062 so'z, o'rtacha 847). Loyiha yakunlandi. 111–148 faktlari `Мавзу1` matnlaridan olindi. Tasdiqlanmagan-ma'lumot bo'limlari (Rossiya hujjatlari/milliy me'yor tekshirilmagan): 092, 093, 094, 101, 118, 121, 128, 131, 137, 138, 141, 142, 143, 146 (oldingilar: 008, 022, 048, 050, 064, 066, 069, 073, 074, 079). Saboq: 13–15 bo'lim (har biri 2 abzats, 45–55 so'z) birinchi qurishda 800+ beradi; 12 bo'limda 780–795 chiqadi.
- 2026-11-11: foydalanuvchi talabi bilan esse uslubida yozish tartibi SKILL.md ga kiritildi (3-bandda ishora va yangi 3.1-bo'lim: tuzilma, abzats hajmi, 13+ bo'lim qoidasi, abzats oxiridagi havola, manba bilan ishlash, ishlash tartibi).
- 2026-11-11: SKILL.md dagi skript yo'llari `D:\TEST\.claude\skills\...` dan haqiqiy joy `C:\Users\xkomilov\.claude\skills\...` ga almashtirildi (3 joy: read_source.ps1, build_docx.js, check_outputs.ps1).
